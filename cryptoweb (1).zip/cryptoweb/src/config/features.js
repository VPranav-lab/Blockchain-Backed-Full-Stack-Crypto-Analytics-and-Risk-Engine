// Simple feature flags so we can ship partial integrations safely.
// Wallet merge is now enabled for the frontend integration build.
export const FEATURES = {
  WALLET: true,
};
